# Tien Nguyen
# Section #
# 1/17/2022
# Tienn@email.sc.edu
# lab 03 moving turtle
import turtle
nguyen = turtle.Turtle()
nguyen.shape('turtle')
nguyen.color('pink')
nguyen.forward(200)
nguyen.backward(30)
nguyen.right(90)
nguyen.forward(100)
nguyen.right(90)
nguyen.forward(50)
nguyen.right(90)
nguyen.forward(100)
nguyen.left(90)
nguyen.forward(80)
nguyen.left(90)
nguyen.forward(100)
nguyen.right(90)
nguyen.forward(40)
nguyen.backward(200)

