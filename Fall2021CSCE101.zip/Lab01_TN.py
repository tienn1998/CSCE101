# Tien Nguyen
# Section #
# 1/12/2022
# tienn@email.sc.edu
# lab 01 variable assignment and print statements 
f_name = "Tien"
l_name = "Nguyen"
color = "blue"
print("Hello World!")
print("My name is {} {}. The sky is {}.".format(f_name, l_name, color))
color = "garnet"
print("My favorite color is {}!".format(color))
print("Thank you from Tien Nguyen")
