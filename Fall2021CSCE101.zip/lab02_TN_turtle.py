# Tien Nguyen
# Section #
# 1/12/2022
# Tienn@email.sc.edu
# lab 02 turtle
import turtle
tien = turtle.Turtle()
tien.shape('turtle')
tien.color('blue')
tien.width(2)
for i in range(8):
    tien.forward(150)
    tien.left(45)
